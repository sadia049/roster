<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RosterShiftsGroupOptions extends Model
{
    public $timestamps = false;
    protected $table = 'rs_shift_group_options';
    protected $fillable = ['group_id', 'shift_id'];
}
