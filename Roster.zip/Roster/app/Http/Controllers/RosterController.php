<?php
namespace App\Http\Controllers;
require __DIR__.'../../../../vendor/autoload.php';
use Session;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Redirect;

use App\RosterShifts;
use App\RosterShiftsGroups;
use App\RosterShiftsGroupOptions;
use App\RosterRosters;
use App\RosterCompanyRosters;
use App\RosterEmployeeRosters;
use App\RosterEmployeeAttendance;
use App\Employee;

use App\User;

use App\Helpers\DataHealper;



class RosterController extends Controller
{
    //
    public function __construct()
    {
        
        $this->middleware('auth');

        $this->middleware(function ($request, $next) {
            if(Session::has('acl'))
            {
                $this->acl = Session('acl');
            }
            return $next($request);            
        });
    }
    
    private function acl(Request $request , $acl)
    {
        $user_type = $request->session()->get('user_type');
        $user_level = $request->session()->get('user_level');
        if(!in_array($user_type , $acl['allowed_user_type']) or !in_array($user_level , $acl['allowed_user_access_level']))
            return false;
        else
            return true;
    }
    
    
    public function dashboard(Request $request){
     

        // $acl['allowed_user_type'] = array("1", "2" , "3");
        // $acl['allowed_user_access_level'] = array("1", "2" , "3" , "4");        
        // if(!AppHelper::acl($request , $acl))
        //     return Redirect::back()->withErrors(['You are not authorized to access this.']);
        if($request->session()->get('company_id'))
        {
            return view('roster.dashboard');
        }
        else 
        {
            return Redirect::to('company')->withErrors(['Please select company.']);
        }
   } 
   
   
   public function rostergroupdetails(Request $request){
     
        if($request->session()->get('company_id'))
        {
            return view('roster.rostergroupdetails');
        }
        else 
        {
            return Redirect::to('company')->withErrors(['Please select company.']);
        }
   } 
   
   
   
   
 public function shifts(Request $request)
    {
       
       $shifts = null;
       $company_id = $request->session()->get('company_id');
       try{
        $company_id = $request->session()->get('company_id');
        $status = isset($request->status) ? $request->status : false;
        $shift_query = RosterShifts::where('company_id', $company_id);
        
        if($status !== false)
        $shift_query = $shift_query->where('status',$status);
        
        if(isset($request->data_type) && $request->data_type =='list'){
        $shift_data = $shift_query->select('id', 'title')->get();
        if($shift_data->isNotEmpty()){
            $shift_rows = $shift_data->toArray();
            if($shift_rows){
                $n = 1;
                foreach($shift_rows as $shift){
                $shift_info['value'] = $shift['id'];
                $shift_info['text'] =  $shift['title'];
                $shift_info['index'] = $n++;
                $shifts[] =  $shift_info;
                }
                
            }
            
        }
        }
        else{
         $shift_data = $shift_query->select('id','title', 'start', 'end', 'status')->get();
         if($shift_data->isNotEmpty()){
           $shift_rows = $shift_data->toArray();
           foreach($shift_rows as $shift){
            
                $shift['start_format'] = '';
                $shift['end_format'] = '';
                
                if($shift['start'] != '00:00:00')
                $shift['start_format'] = date('h:i A', strtotime($shift['start']));
                
                if($shift['end'] != '00:00:00')
                $shift['end_format'] = date('h:i A', strtotime($shift['end']));
                
                $shifts[] =  $shift;
           } 
         }
        }
        return response()->json($shifts);
       }
       catch(Throwable $e)
        {
            return $e;
        }
    }
    
 


public static function iscompanyoffday($date){
  $day_name = date('l',strtotime($date));
  $day_name = strtolower($day_name);
  if($day_name =='friday')
  return true;
  else
  return false;
}

public function getleavelistsemployees($employees = array()){
}
 
public function getpoolemployees($company_id,$pool,$date_start,$date_end){
    $active_employees = array();
    $is_off_day = $this->iscompanyoffday($date_start);
    if($is_off_day)
    return false;
    
    if($company_id && $pool && $date_start && $date_end){
     $company_active_employees =   DataHealper::company_active_employees_between_dates($company_id,$date_start,$date_end);
     
     $roster_pools = $this->rosterpools();
     $roster_pools = array_reverse($roster_pools);
     
     if($company_active_employees && $roster_pools){
        foreach($company_active_employees as $emp){
            foreach($roster_pools as $pool_value){
                //echo;
               if($emp->employee_id % $pool_value['value'] == 0){
                 $pool_id =  $pool_value['value'];
                 $active_employees[$pool_id][] = $emp->employee_id;
                 break; 
               }
            }
            
           //$active_employees[] =  $emp->employee_id;
        }
     }
    }   
    
    return $active_employees[$pool];
 }
   
 public function make_roster($employees, $shifts){
    $rosters = array();
    $all_shifts = array();
    if($employees && $shifts){
    foreach($shifts as $shift_id => $shift){
       $all_shifts[]  = array('id'=>$shift_id,'value'=>$shift);
    }
    
    $shift_loop = 0;
    $shift_len = count($all_shifts);
    foreach($employees as $employee){
      $rosters[$all_shifts[$shift_loop]['id']][]  = $employee;
      $shift_loop++;
      if($shift_loop >= $shift_len)
      $shift_loop = 0;
    }
    
   }
   return $rosters;
 }
 
    
 public function saverosterdata(Request $request)
    {

        $status = false;
        $request->validate(['pool' => 'required','shift' => 'required','month' => 'required','year' => 'required']);
        
        try{    
            
            

            $company_id = $request->session()->get('company_id');
            
            $pool = $request->pool;
            $shift_group = $request->shift;
            
            $month = date("n",strtotime($request->month));
            $year  = $request->year;
            

            
            $total_days = cal_days_in_month(CAL_GREGORIAN, $month, $year);
            
            //echo $total_days;
          
            $date_start = $year."-".$month."-01";
            $date_end = $year."-".$month."-".$total_days;
            

            //$company_active_employees =   DataHealper::company_active_employees_between_dates($company_id,$date_start,$date_end);
            
            
            $shifts = $this->shiftgroupoptions($shift_group);
            
            
            
            /*print_r($rosters);
            return 1;

            $form_data = array();
          
            $form_data['title'] = $request->title;
            $form_data['status'] = $request->status;*/
            
            
            $user_id = Auth::user()->id;
            //echo $request->document;      
            if($shifts){ 
                $roster_id = RosterRosters::insertGetId(array('company_id'=>$company_id,'pool_id'=>$pool,'shift_id'=>$shift_group,'created_by'=>$user_id,'start_date'=>$date_start,'end_date'=>$date_end,'status'=>1));
     
                $start_date_array = explode("-",$date_start);
                $end_date_array = explode("-",$date_end);
                
                $start_loop = end($start_date_array);
                $end_loop = end($end_date_array);
                
                while($start_loop<= $end_loop){
                $date_value = $year."-".$month."-".$start_loop;
                
                $pool_employees = $this->getpoolemployees($company_id,$pool,$date_value,$date_value);
                
                if($pool_employees){
                $rosters = $this->make_roster($pool_employees,$shifts);
                
                foreach($rosters as $shift_id => $roster_info){
                  $company_roster_id = RosterCompanyRosters::insertGetId(array('company_id'=>$company_id,'pool_id'=>$pool,'shift_id'=>$shift_id,'rs_id'=>$roster_id,'created_by'=>$user_id,'start_date'=>$date_value,'end_date'=>$date_value,'status'=>1));
                  if($company_roster_id){
                    foreach($roster_info as $employee_id){
                        RosterEmployeeRosters::create(array('company_id'=>$company_id,'employee_id'=>$employee_id,'roster_id'=>$company_roster_id));
                    }
                  }
                }
                
                }
                
                $start_loop++;
              }
            }
            return response()->json(['success'=>1 , 'message'=>'Saved successfully!']);
        }
        catch(Throwable $e)
        {
            return $e;
        }
    }
    
    
    
    
    public function saveshiftdata(Request $request)
    {

        $status = false;
        $request->validate(['title' => 'required','status' => 'required']);
        
        try{    
            
           

            $company_id = $request->session()->get('company_id');

            

            $form_data = array();
          
            $form_data['title'] = $request->title;
            $form_data['status'] = $request->status;
            $form_data['start'] = $request->start;
            $form_data['end'] = $request->end;
            
            //echo $request->document;      

            
                    
            if($request->id > 0)
            {
                $status = RosterShifts::where("id", $request->id)->update($form_data);
            }
            else
            {
                $form_data['company_id'] = $company_id;
                $status = RosterShifts::create($form_data);
            }        
            if($status)
            return response()->json(['success'=>1 , 'message'=>'Saved successfully!']);
        }
        catch(Throwable $e)
        {
            return $e;
        }
    }
    
    public function shiftdetails(Request $request)
    {
        $data = RosterShifts::where("id", $request->id)->select('id', 'title','start','end','status')->first();
        return response()->json($data);
    }
    
    public function shiftdelete(Request $request)
    {
        try{
            $company_id = $request->session()->get('company_id');
            $data = array();

            if(RosterShiftsGroupOptions::where('shift_id', '=', $request->id)->exists()) 
            {
                $data['status'] = false;
                $data['msg'] = 'Shift group is using this shift. Please delete the Shift Group first to continue..';
            }
            else
            {
                $title = RosterShifts::find($request->id)->title;

                if(RosterShifts::where('id', '=', $request->id)->delete())
                {
                    $data['status'] = true;
                    $data['msg'] = "Successfully deleted.";    
                    
                    $action_name = 'Delete';
                    $module_name = 'Roster';
                    $log_details = 'Shift named  '.$title.' is deleted';
                    app('App\Http\Controllers\UserLogController')->create_activity_log($request , $log_details , $module_name , $action_name);
                }
                
            }

            return response()->json($data);
        }
        catch(Throwable $e)
        {
            return $e;
        }
    }
    
    
    public function saveshiftgroupdata(Request $request)
    {


        //print_r($request->shifts);
        //return false;
        $status = false;
        $request->validate(['title' => 'required','shifts' => 'required']);
        
        try{    
            
           

            $company_id = $request->session()->get('company_id');

            

            $form_data = array();
          
            $form_data['title'] = $request->title;
            $form_data['status'] = $request->status;
            
            $shift_lists = explode(',',$request->shifts);
            
            //echo $request->document;      

            
                    
            if($request->id > 0)
            {
                $status = RosterShiftsGroups::where("id", $request->id)->update($form_data);
                
                if($shift_lists){
                 RosterShiftsGroupOptions::where('group_id', '=', $request->id)->delete();
                 $status = true;
                }
                $group_id = $request->id;
               
            }
            else
            {
                $form_data['company_id'] = $company_id;
                $group_id = RosterShiftsGroups::insertGetId($form_data);
                $status = true;
            }        
            if($status){
                if($shift_lists){
                    $opt_data['group_id'] = $group_id;
                    
                    foreach($shift_lists as $shift){
                      $opt_data['shift_id'] = $shift;
                      $opt_status = RosterShiftsGroupOptions::create($opt_data);  
                    }
                }
                
                return response()->json(['success'=>1 , 'message'=>'Saved successfully!']);
            }
            
        }
        catch(Throwable $e)
        {
            return $e;
        }
    }
    


 public function custom_roster_info(Request $request)
    {
       
       $shiftgroups = [];
       $company_id = $request->session()->get('company_id');
       $roster_id = $request->roster_id;
       try{
        if($roster_id){
        
        $roster_info = RosterRosters::where('id', $roster_id)->select('id','pool_id','shift_id')->first();
        if($roster_info)
        $group_id = $roster_info['shift_id'];
        else
        $group_id = 0;
        
        $group_options = $this->shiftgroupoptions($group_id);
        
        if($group_options){
            foreach($group_options as $g_opt_key => $g_opt_value){
               $shift_info = RosterShifts::where('id', $g_opt_key)->select('start','end')->first(); 
               if($shift_info){
               $text_from_to = date('h:i A', strtotime($shift_info['start'])) . ' to '. date('h:i A', strtotime($shift_info['end']));
               $group_options[$g_opt_key] = $group_options[$g_opt_key] . ' '.$text_from_to;
               
               }
               
            }
            
            $n = 1;
            foreach($group_options as $g_opt_key => $g_opt_value){
                $shift_data['value'] = $g_opt_key;
                $shift_data['text'] =  $g_opt_value;
                $shift_data['index'] = $n++;
                $shiftgroups[] =  $shift_data;
            }
            
        }
        
        }
        return response()->json($shiftgroups);
        
       }
       catch(Throwable $e)
        {
            return $e;
        }
    }
    
    
 public function shiftgroups(Request $request)
    {
       
       $shiftgroups = [];
       $company_id = $request->session()->get('company_id');
       try{
        $company_id = $request->session()->get('company_id');
        $status = isset($request->status) ? $request->status : false;
        $shift_query = RosterShiftsGroups::where('company_id', $company_id);
        
        if($status !== false)
        $shift_query = $shift_query->where('status',$status);
        
        if(isset($request->data_type) && $request->data_type =='list'){
        $shift_data = $shift_query->select('id', 'title')->get();
        if($shift_data->isNotEmpty()){
            $shift_rows = $shift_data->toArray();
            if($shift_rows){
                $n = 1;
                foreach($shift_rows as $shift){
                $shift_info['value'] = $shift['id'];
                $shift_info['text'] =  $shift['title'];
                $shift_info['index'] = $n++;
                $shiftgroups[] =  $shift_info;
                }
                
            }
            
        }
        }
        else{
        $shiftgroupdata = $shift_query->select('id','title','status')->get();
        if($shiftgroupdata){
           if($shiftgroupdata->isNotEmpty()){
            $shift_group_rows = $shiftgroupdata->toArray(); 
            foreach($shift_group_rows as $shift_group_row){
              $shift_names = $this->shiftgroupoptions($shift_group_row['id']);
              $shift_group_row['shift_names'] = implode(" , ",$shift_names);
              $shiftgroups[] = $shift_group_row;
            }
           }
        }
        
        
        }
        
        
        
        return response()->json($shiftgroups);
       }
       catch(Throwable $e)
        {
            return $e;
        }
    }
    
    public function shiftgroupoptions(int $group_id, $status=0)
    {
       
       $shiftgroupoptions = null;
       
       $shiftgroupoptiondata = RosterShiftsGroupOptions::where('group_id', $group_id)->pluck('shift_id')->toArray();
       if($shiftgroupoptiondata)
       $shiftgroupoptions = RosterShifts::whereIn('id',$shiftgroupoptiondata)->pluck('title','id')->toArray();
       
       return $shiftgroupoptions;
    }
    
    
    public function shiftgroupdetails(Request $request)
    {
        $data = RosterShiftsGroups::where("id", $request->id)->select('id', 'title', 'status')->first();
        if($data){
            $group_options = $this->shiftgroupoptions($data['id']);
            if($group_options){
            $group_opts = array_keys($group_options);
            $data['group_options'] = $group_opts;
            }
        }
        
        return response()->json($data);
    }
    
 public function shiftgroupdelete(Request $request)
    {
        try{
            $company_id = $request->session()->get('company_id');
            $data = array();

                $title = RosterShiftsGroups::find($request->id)->title;

                if(RosterShiftsGroups::where('id', '=', $request->id)->delete())
                {
                    RosterShiftsGroupOptions::where('group_id',$request->id)->delete();
                    
                    $data['status'] = true;
                    $data['msg'] = "Successfully deleted.";    
                    
                    $action_name = 'Delete';
                    $module_name = 'Roster';
                    $log_details = 'Shift Group named  '.$title.' is deleted';
                    app('App\Http\Controllers\UserLogController')->create_activity_log($request , $log_details , $module_name , $action_name);
                }
                
            

            return response()->json($data);
        }
        catch(Throwable $e)
        {
            return $e;
        }
    }
    
    
  public static function rosterpools()
    {
       
     $pools = array(
       array('value'=>1,'text'=>'Test Pool 1','index'=>1),
       array('value'=>2,'text'=>'Test Pool 2','index'=>2),
       array('value'=>3,'text'=>'Test Pool 3','index'=>3),
       array('value'=>4,'text'=>'Test Pool 4','index'=>4),
       );
    
       return $pools;
    } 
 
 
  public static function get_roster_pool_data($pools = array()){
    $pool_data = array();
    if($pools){
       $all_pools = self::rosterpools();
       foreach($all_pools as $pool){
        if(in_array($pool['value'],$pools)){
           $pool_data[$pool['value']] = $pool['text'];
        }
       }  
    }
    return $pool_data; 
  }
  
  public static function get_roster_shift_data($shifts = array()){
    $shift_data = array();
    if($shifts){
       $shift_data =  RosterShifts::whereIn('id',$shifts)->pluck('title','id')->toArray();
    }
    return $shift_data; 
  }
  
  public static function get_roster_shift_group_data($shifts = array()){
    $shift_data = array();
    if($shifts){
       $shift_data =  RosterShiftsGroups::whereIn('id',$shifts)->pluck('title','id')->toArray();
    }
    return $shift_data; 
  }
  
  
  public static function filter_roster_data($rosters){
    $filtered_rosters = array();
    $pools = array();
    $shifts = array();
    if($rosters){
      //print_r($rosters);
      foreach($rosters as $roster){
        if($roster['pool_id'] && !in_array($roster['pool_id'],$pools))
        $pools[] = $roster['pool_id'];
        
        if($roster['shift_id'] && !in_array($roster['shift_id'],$shifts)){
            
        }
        $shifts[] = $roster['shift_id'];
      } 
      
      if($pools)
      $pools = self::get_roster_pool_data($pools);
      
      if($shifts)
      $shifts = self::get_roster_shift_group_data($shifts);
      
      foreach($rosters as $key => $roster){
        if($roster['pool_id'])
        $rosters[$key]['pool'] = $pools[$roster['pool_id']];
        
        if($roster['shift_id'])
        $rosters[$key]['shift'] = $shifts[$roster['shift_id']];
        
        $rosters[$key]['start_month'] = '';
        $rosters[$key]['start_year'] = '';
        
        if($roster['start_date']){
            $start_time = strtotime($roster['start_date']);
            $rosters[$key]['start_month'] = date('F', $start_time);
            $rosters[$key]['start_year'] = date('Y', $start_time);
        }
      }
      $filtered_rosters = $rosters;
    }
    return $filtered_rosters;
  }
    
  public function allrosters(Request $request)
    {
       
       $rosters = null;
       $company_id = $request->session()->get('company_id');
       try{
        $company_id = $request->session()->get('company_id');
        $status = isset($request->status) ? $request->status : false;
        $roster_query = RosterRosters::where('company_id', $company_id);
        if($status !== false)
        $roster_query = $roster_query->where('status',$status);
        $roster_data = $roster_query->select('id','pool_id', 'shift_id', 'start_date','end_date','status')->get();
        
        if($roster_data->isNotEmpty()){
        $rosters = $roster_data->toArray(); 
        $rosters = $this->filter_roster_data($rosters);
        }
        
        //return 1;
        
        
        return response()->json($rosters);
       }
       catch(Throwable $e)
        {
            return $e;
        }
    }
    
    
    
  public static function get_roster_shift_dates($rs_id,$shift_id,$pool_id){
    $dates_lists = array();
    if($rs_id && $shift_id){
       $dates_lists =  RosterCompanyRosters::where('rs_id',$rs_id)->where('shift_id',$shift_id)->where('pool_id',$pool_id)->pluck('start_date','id')->toArray();
    }
    return $dates_lists; 
  }
    
    
    public function shiftrosterdetails(Request $request)
    {
       
       $roster_details = null;
       $date_lists = array();
       $company_id = $request->session()->get('company_id');
       try{
        $company_id = $request->session()->get('company_id');
        $roster_id = isset($request->roster_id) ? $request->roster_id : false;
        $rs_id = isset($request->rs_id) ? $request->rs_id : false;
        $shift_id = isset($request->shift_id) ? $request->shift_id : false;
        $pool_id = isset($request->pool_id) ? $request->pool_id : false;
        $roster_date = isset($request->roster_date) ? $request->roster_date : false;
        
        if($shift_id && $rs_id && $pool_id){
    
        $date_list_data = $this->get_roster_shift_dates($rs_id,$shift_id,$pool_id);
        
        if($date_list_data){
            $n = 1;
            foreach($date_list_data as $rs_key => $date_value){
                $rs_data['value'] = $rs_key;
                $rs_data['text'] =   date("F j, Y",strtotime($date_value));
                $rs_data['index'] = $n++;
                $date_lists[] =  $rs_data;  
            }
        }
        
        
        //return $date_lists;
        if($roster_id){
           $roster_info = RosterCompanyRosters::where('rs_id', $rs_id)->where('shift_id', $shift_id)->where('id', $roster_id)->select('id','start_date')->first();
        }else{
           $roster_info = RosterCompanyRosters::where('rs_id', $rs_id)->where('shift_id', $shift_id)->orderBy('id', 'ASC')->select('id','start_date')->first(); 
           $roster_id =  $roster_info['id'];
        }
        
        
        if($roster_id){
           $employee_rosters = RosterEmployeeRosters::where('roster_id', $roster_id)->select('id','employee_id')->get()->toArray();
            //print_r($employee_rosters);
            //return 1;
           if($employee_rosters){
             foreach($employee_rosters as $er_key => $er_value){
                $employee_info = Employee::where('employee_id', $er_value['employee_id'])->select('name','employee_code')->first();
                $employee_rosters[$er_key]['name'] = $employee_info['name'];
                $employee_rosters[$er_key]['employee_code'] = $employee_info['employee_code'];
             }
           }
        }
        
        //print_r($employee_rosters);
        //return 1;
        /*$roster_query = RosterRosters::where('company_id', $company_id);
        if($status !== false)
        $roster_query = $roster_query->where('status',$status);
        $roster_data = $roster_query->select('id','pool_id', 'shift_id', 'start_date','end_date','status')->get();
        
        if($roster_data->isNotEmpty()){
        $rosters = $roster_data->toArray(); 
        $rosters = $this->filter_roster_data($rosters);
        }*/
        
        $roster_details['date_lists'] = $date_lists;
        $roster_details['roster_selected'] = $roster_id;
        $roster_details['roster_data'] = $employee_rosters;
        
        //return 1;
        }
        
        return response()->json($roster_details);
       }
       catch(Throwable $e)
        {
            return $e;
        }
    }
    
    
    public function updateemployeeshift(Request $request)
    {


        //print_r($request->shifts);
        //return false;
        $status = false;
        $request->validate(['shift' => 'required','employee_id' => 'required', 'roster_id' => 'required']);
        
        try{    
            
           

            $company_id = $request->session()->get('company_id');

            $roster_id = $request->roster_id;
            $shift = $request->shift;
            $employee_id =  $request->employee_id;

            //echo 'here '.$roster_id;

            
                    
            if($roster_id > 0)
            {
                
                $company_roster_id = RosterEmployeeRosters::where('id', $roster_id)->value('roster_id');
                $roster_info = RosterCompanyRosters::where('id', $company_roster_id)->select('id','rs_id','pool_id')->first();
                //print_r($roster_info);
                if($roster_info){
                $updated_roster_id = RosterCompanyRosters::where('rs_id', $roster_info['rs_id'])->where('pool_id',$roster_info['pool_id'])->where('shift_id',$shift)->value('id');
                
                //echo $updated_roster_id; return 1;
                
                $status = RosterEmployeeRosters::where("roster_id", $company_roster_id)->where('employee_id',$employee_id)->update(array('roster_id'=>$updated_roster_id));
                
                }
                
               
            }
                  
            if($status)
            return response()->json(['success'=>1 , 'message'=>'Saved successfully!']);
            
            
        }
        catch(Throwable $e)
        {
            return $e;
        }
    }
    
    
    
    
    
    
}
