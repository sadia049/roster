<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RosterEmployeeRosters extends Model
{
    public $timestamps = false;
    protected $table = 'rs_employee_rosters';
    protected $fillable = ['company_id', 'employee_id', 'roster_id'];
}
