<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RosterShiftsGroups extends Model
{
    public $timestamps = false;
    protected $table = 'rs_shift_groups';
    protected $fillable = ['company_id', 'title','status'];
}
