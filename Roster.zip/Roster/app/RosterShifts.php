<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RosterShifts extends Model
{
    public $timestamps = false;
    protected $table = 'rs_shifts';
    protected $fillable = ['title', 'company_id', 'start', 'end','status'];
}
