<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RosterRosters extends Model
{
    public $timestamps = false;
    protected $table = 'rs_rosters';
    protected $fillable = ['company_id', 'pool_id', 'shift_group_id','created_by','start_date','end_date','status'];
}
