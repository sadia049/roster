<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RosterEmployeeAttendance extends Model
{
    public $timestamps = false;
    protected $table = 'rs_employee_attendance';
    protected $fillable = ['company_id', 'employee_id', 'roster_id','attendances_date','check_in','checkout'];
}
