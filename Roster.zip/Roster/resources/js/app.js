//=========Roster module=============================/

Vue.component('roster-dashboard',require('./components/RosterDashboard.vue').default);
Vue.component('roster-settings',require('./components/RosterSettings.vue').default); // 11-08-2023
Vue.component('roster-shifts', require('./components/RosterShifts.vue').default);
Vue.component('roster-shift-groups', require('./components/RosterShiftGroups.vue').default);
Vue.component('all-rosters', require('./components/AllRosters.vue').default);
Vue.component('roster-group-details', require('./components/RosterGroupDetails.vue').default);

//=========End Roster module=========================/