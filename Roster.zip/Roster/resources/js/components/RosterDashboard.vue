<template>

    <div class="employee-tab-inner">        
        <!--<ul class="list-group mb-3 " v-if='errormsg'>           
            <li class="list-group-item list-group-item-danger" v-for='data in errormsg'>{{data[0]}}</li>
        </ul>-->   
        
        
        <h4 class="atlhr-dashboard-title mt-10 px-0 mb-4">Company Rosters<span><a v-bind:href="pageurl+'/company/dashboard'">Dashboard</a> / Company Rosters</span></h4>  
        

        
    
        <b-overlay :show="showoverlay" rounded="sm">
            <div class="pf-reporting-tab payroll-reporting-tab" id="nav-tabContent-intro3">
                 <b-tabs content-class="mt-3 reports-tab-wrapper" nav-wrapper-class="mb-2 mt-2 reports-tab-nav-wrapper">
                                        
                    
                        <b-tab lazy active>

                            <template #title>
                                <div class="report-title w-100 border-bottom font-weight-bold pb-2 mb-2">
                                    <img v-bind:src="pageurl+'/public/images/Monthly-report-black.png'" class="light-mode-icon" width="50px"/><img v-bind:src="pageurl+'/public/images/Monthly-report.png'" class="dark-mode-icon" width="50px"/>Settings
                                </div>
                                <div class="report-intro">
                                    Roster Settings
                                </div>
                                <b-button class="mt-3">View</b-button>
                            </template>
                            <div class="">
                            <roster-settings :pageurl="pageurl"></roster-settings>
                            </div>
                        </b-tab>
                        
                        
                        <b-tab lazy active>

                            <template #title>
                                <div class="report-title w-100 border-bottom font-weight-bold pb-2 mb-2">
                                    <img v-bind:src="pageurl+'/public/images/Monthly-report-black.png'" class="light-mode-icon" width="50px"/><img v-bind:src="pageurl+'/public/images/Monthly-report.png'" class="dark-mode-icon" width="50px"/>Rosters
                                </div>
                                <div class="report-intro">
                                    Rosters
                                </div>
                                <b-button class="mt-3">View</b-button>
                            </template>
                            <div class="">
                            <all-rosters :pageurl="pageurl"></all-rosters>
                            </div>

                        </b-tab>
                        
                        
                        
                       <!-- <b-tab lazy active>

                            <template #title>
                                <div class="report-title w-100 border-bottom font-weight-bold pb-2 mb-2">
                                    <img v-bind:src="pageurl+'/public/images/Monthly-report-black.png'" class="light-mode-icon" width="50px"/><img v-bind:src="pageurl+'/public/images/Monthly-report.png'" class="dark-mode-icon" width="50px"/>Investments
                                </div>
                                <div class="report-intro">
                                    All Investments
                                </div>
                                <b-button class="mt-3">View</b-button>
                            </template>
                            <div class="">
                            <all-investments :pageurl="pageurl"></all-investments>
                            </div>

                        </b-tab>   -->              

                </b-tabs>
            </div>
            
      
        </b-overlay>
        
    </div>
    
</template>
 
<script>
    import moment from 'moment';

    export default{
        
        mounted() {
            
            this.showoverlay = false;
        },
        props: ['flg','pageurl'],

        data(){            
            
            return {
                
                


                componentKey: 0,
                     
                cu:window.location.href,
                successmsg : false,
                warningmsg : false,
                dangermsg : false,
                showoverlay : true,
                //susdoverlay : false,
                readonly : false,
                user_level : 0,
                

                errormsg:[],
                
                fdata: {
                        },

                susd: '',
                roster_details: 0,
            }
        },
        methods:{
            
            
            
        },
        computed: 
        {
        },
        created: function(){
            if(!this.checkNet()) return false;
            this.$validator.reset();
        }
    }
</script> 
