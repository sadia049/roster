<template>       
    <div class="clearfix company-form-container rounded mt-4 pb-5 mx-auto pl-3 pr-3">
        
        

        <div class="clearfix row py-2 mb-2 border-bottom">       
            <div class="col-sm-3 px-3 company-form-box-title">Rosters</div> 
            <div class="col-sm-4">     
                <div class="custom-search float-right w-100">           
                    <b-input-group class="mb-0">
                        <b-input-group-prepend is-text>
                            <b-icon icon="search"></b-icon>
                        </b-input-group-prepend>
                        <b-form-input type="search" placeholder="Search.." v-model="search" @input="resetPagination()"></b-form-input>
                    </b-input-group>
                </div>
            </div>
            <div class="col-sm-5 float-right text-right px-0">
                <b-button id="show-btn" class="" @click="addNew(false)">Add Roster</b-button>
            </div>
        </div> 

        
        
        <div class="row justify-content-center">
            <div class="col-sm-12  px-0">
                <b-modal id="bv-modal-roster" size="lg" hide-footer title="Roster Details">
                    <b-overlay :show="showoverlay" rounded="sm">
                    
                    <b-form @submit.stop.prevent="onSubmit" >      
                             
              
                <ul class="list-group mb-3 " v-if='disable_msg'>           
                    <li class="list-group-item list-group-item-danger">{{disable_msg}}</li>
                </ul>
                
                <ul class="list-group mb-3 " v-if='errormsg'>           
                    <li class="list-group-item list-group-item-danger" v-for='data in errormsg'>{{data[0]}}</li>
                </ul>
                <div class="clearfix">
                    
                    <ul class="list-group mb-3 " v-if='errormsg'>           
                        <li class="list-group-item list-group-item-danger" v-for='data in errormsg'>{{data[0]}}</li>
                    </ul> 
                    <div class="col-md-12 float-left">     
                        
                        
                        <b-form-group id="roster-date-group" label="Roster For" label-for="month_selected" class="required-field">
                            <b-form-select v-model="month_selected" :options="month_lists" class="w-25" v-validate="{ required: true }"></b-form-select>
                            <b-form-select v-model="year_selected" :options="year_lists" class="w-25" v-validate="{ required: true }"></b-form-select>
                        </b-form-group>
                        <b-form-group id="pool-group" label="Pool" label-for="pool" class="required-field">
                            <b-form-select name="Pool" class='form-control' v-model="pool" :options="pools" v-validate="{ required: true }" :state="validateState('pool')" aria-describedby="pool-feedback" data-vv-as="Pool">
                            </b-form-select>
                            <b-form-invalid-feedback id="pool-feedback">{{ veeErrors.first('pool') }}</b-form-invalid-feedback>
                        </b-form-group>         
                       
                        <b-form-group id="roster_shift-group" label="Shift(Group)" label-for="roster_shift" class="required-field">
                            <b-form-select name="roster_shift" class='form-control' v-model="shift_group" :options="shiftgroups" v-validate="{ required: true }" :state="validateState('roster_shift')" aria-describedby="roster_shift-feedback" data-vv-as="Shift(Group)">
                            </b-form-select>
                            <b-form-invalid-feedback id="roster_shift-feedback">{{ veeErrors.first('roster_shift') }}</b-form-invalid-feedback>
                        </b-form-group>
                    </div>
                
 
                    
                    <div class="col-md-12 float-right">
                        <div class="mt-4 ml-4">
                            <b-button type="submit" class="border rounded float-right py-1 px-5 mt-4 ml-2"  variant="success">Submit</b-button>
                            <!-- <b-button class="ml-2 border rounded float-right py-1 px-5 mt-4" variant="success" @click="resetForm()">Reset</b-button> -->
                        </div>
                    </div>               
                </div>          

                </b-form>
                </b-overlay>
                </b-modal>
                
                
                <b-modal id="bv-modal-roster-group-details" size="lg" hide-footer title="Roster Details">
                    <roster-group-details :pageurl="pageurl" :roster="roster_id" :rostertitle="roster_title" :pool="pool_id"></roster-group-details>
                </b-modal>
                

            </div>
    
    
            <div class="col-sm-12  px-0">            
                <b-overlay :show="showoverlay_list" rounded="sm">
                    <table class="table list-tables"> 
                        <thead>
                            <tr class="table-head">
                                <td class="pl-5">#</td>
                                <td class="">Roster For</td>
                                <td>Roster Pool</td>
                                <td>Roster Shift</td>
                                <td v-if="permission >= 2" class="float-right">Action</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="hover-bg table-row border-bottom mx-2" v-for="(roster , n) in paginatedData" :key="roster.id">
                                <td class="col-md-1 align-middle list-columns pl-5">{{roster.index}}</td>
                                <td class="col-md-2">
                                    {{roster.start_month}} {{roster.start_year}}
                                </td>
                                <td class="col-md-3 align-middle list-columns">
                                    {{roster.pool}}
                                </td>  
                                <td class="col-md-2 align-middle list-columns">
                                    {{roster.shift}}
                                </td>
                                   
                                                               
                                <td class="clearfix col-md-6 align-middle" v-if="permission >= 2">                        
                                    <div class="float-right mr-2 position-relative">
                                        <b-button-toolbar>
                                            <a id="actionDropdown" class="dropdown-toggle clearfix action-dropdown-toggle" style="font-size: 16px;" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><b-icon icon="three-dots-vertical"></b-icon></a>
                                             <div class="dropdown-menu action-dropdown-menu" aria-labelledby="actionDropdown">
                                                <b-button-group class="mr-0">
                                                    <b-button class="mr-3 rounded edit-btn" title="Edit Roster" @click="rosterGroupDetails(roster.id,roster.pool_id,roster.start_month,roster.start_year)">
                                                        <b-icon icon="box-arrow-in-right" class="mr-2" aria-hidden="true" ></b-icon>Details
                                                    </b-button>
                                                </b-button-group>
                                            </div>
                                        </b-button-toolbar>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div v-if="paginatedData.length == 0" class="px-3 py-3 no-result-cell">No Result Found!</div>
                    <div v-else class="px-3">
                        <ul class="pagination b-pagination float-left mb-0 mt-1">
                            <li class="page-item disabled m-2">View</li>
                            <li class="page-item disabled"><b-form-select v-model="temp_length" :options="length_options" @change="setFirstPage()"></b-form-select></li>
                            <li class="page-item disabled m-2">per page. Total {{people}} records found.</li>
                        </ul>
                        <b-pagination-nav  v-model="pagination.currentPage" :number-of-pages="pagination.pages" base-url="#" prev-text="Previous" next-text="Next" first-number last-number ></b-pagination-nav>
                        
                    </div>
                
                
                
                    <div v-if="this.flg == 1" class="mt-3">                            
                        <b-button type="button" @click="set_go_next(1)" variant="primary" class="float-right mt-3 mr-3">Go Next</b-button>
                        <b-button type="button" @click="set_go_back(1)" variant="primary" class="float-right mt-3 mr-3">Go Back</b-button>
                        <b-button type="button" @click="setfinish(1)" variant="success" class="float-right mt-3 mx-3">Finish</b-button>
                    </div>
                
                </b-overlay>
            </div>

        </div>
        
    </div>
</template>


<script>
    export default{
        
        mounted() {
            this.permission = this.$acl['department/details'];
        },
        props: ['pageurl' , 'ce_flg' , 'check_ce' , 'flg'],
        data(){            
            
            return {                
                
                bankaccounts:[],             
                successmsg:null,
                errormsg:[],
                warningmsg:null,
                fdata: {bank:null, account_number: null, id:null, category: null,amount: null, interest_rate: null,institution_name: null, start_date: null, end_date:null, details_reference: null,investment_option: null},
                saved_name : '',

                draftdata : {},
                pgurl:this.pageurl,
                file: null,   
                showoverlay:false,
                showoverlay_list:false,
                go_back : false,
                go_next : false,
                finish : false,
                
                search:'',
                length: 20,
                temp_length:20,
                people:0,
                length_options: 
                [
                    { value: 20, text: "20" },
                    { value: 50, text: "50" },
                    { value: 100, text: "100" }
                ],
                account_status: {0: "Pending", 1:"Active", 2: "Archived"},

                people:0,
                pagination: {currentPage: 1, pages:1},

                successmsg:false,
                warningmsg:false,
                dangermsg:false,

                addtype : false,
              
                max_investable_amount: 0,
                permission : 0,
                hasDraft : false,
                document : null,
                banks: [],
                investment_categories: [],
                investment_options:[{ value: null, text: "Select" },
                   { value: 0, text: "Simple" },
                   { value: 1, text: "Compound" },
                ],
                disable_msg: '',
                year_selected: null,
                month_lists: ["January","February","March","April","May","June","July","August","September","October","November","December"],
                month_selected: null,
                shift_group: 0,
                shiftgroups: [],
                pool: 0,
                pools: [],
                roster_id: 0,
                roster_title: '',
                pool_id: 0,
                
            }
        },
        methods:{
            
            showMessage: function()
            {
                let tmp_flg = 0;
                if(this.bankaccounts.length > 0)tmp_flg = 1;               
                let childdata = {flg:tmp_flg , successmsg:this.successmsg , warningmsg:this.warningmsg , dangermsg:this.dangermsg,  move_next:this.go_next , move_back:this.go_back , finish:this.finish};                    
                this.$emit('childToParent', childdata);
            },
            set_go_back(x){
                this.go_next = false;
                this.go_back = true;
                this.finish = false;

                if(x == 1)
                    this.showMessage();
            },
            set_go_next(x){
                this.go_next = true;
                this.go_back = false;
                this.finish = false;

                if(x == 1)
                    this.showMessage();
            },
            disable_set_go_next(){
                this.go_next = false;
            },
            setfinish(x){
                this.finish = true;

                this.go_next = false;
                this.go_back = false;

                if(x == 1)
                    this.showMessage();
            },


            addNew(x)
            {
                this.addtype = x;
                this.resetForm();
                this.$bvModal.show('bv-modal-roster');
                //this.newagent = true;
            },
            getRosters: function()
            {
                if(!this.checkNet()) return false;
                let currentObj = this;
                axios.get(this.pageurl+'/roster/rosters' , {
                    params: {
                        //employee_id: this.employeeId
                    }
                }).then(function(response){
                    this.bankaccounts = response.data;
                    this.people = this.bankaccounts.length;
                    //this.showMessage();

                }.bind(this)).catch(function (error){currentObj.serverError(error);});
            },
            
            /*rosterGroupDetails:function(x)
            {  
                this.addtype = false;
                if(!this.checkNet()) return false;
                let currentObj = this; 
                this.showoverlay = true;
                axios.get(this.pageurl+'/roster/groupdetails' , {
                    params: {
                        id: x
                    }
                }).then(function(response){
                    this.fdata = response.data;
                    this.document = null;
                    this.$validator.reset();                    
                    this.showoverlay = false;
                    this.$bvModal.show('bv-modal-roster');
                    //currentObj.getBankAccountInvestableAmount(this.fdata.bank);
                }.bind(this)).catch(function (error){currentObj.showoverlay = false; currentObj.serverError(error);}); ;                
            },*/
            rosterGroupDetails:function(id,pool,month,year)
            {  
              this.roster_id = id;
              this.pool_id = pool;
              this.roster_title = month + ' '+year;
              this.$bvModal.show('bv-modal-roster-group-details');
                              
            },
           getRosterShiftGroups: function()
            {
                if(!this.checkNet()) return false;
                let currentObj = this;
                axios.get(this.pageurl+'/roster/shiftgroups' , {
                    params: {
                        status: 1,
                        data_type: 'list'
                    }
                }).then(function(response){
                    //this.shiftgroups = response.data;
                    this.shiftgroups = [{ value: null, text: "Select..." } ] . concat(response.data); 
                    //this.totalrows = this.shiftgroups.length;
                    //this.showMessage();

                }.bind(this)).catch(function (error){currentObj.serverError(error);});
            },
            
            getRosterPools: function()
            {
                if(!this.checkNet()) return false;
                let currentObj = this;
                axios.get(this.pageurl+'/roster/pool' , {
                    params: {
                        status: 1,
                        data_type: 'list'
                    }
                }).then(function(response){
                    //this.shiftgroups = response.data;
                    this.pools = [{ value: null, text: "Select..." } ] . concat(response.data); 
                    //this.totalrows = this.shiftgroups.length;
                    //this.showMessage();

                }.bind(this)).catch(function (error){currentObj.serverError(error);});
            },
           
            validateState(ref)
            {
                if (
                    this.veeFields[ref] &&
                    (this.veeFields[ref].dirty || this.veeFields[ref].validated)
                ) {
                    return !this.veeErrors.has(ref);
                }
                return null;
            },
            resetForm()
            {
                this.pool = 0;  
                this.shift_group = 0;           
                this.$nextTick(() => {
                    this.$validator.reset();
                });
            },
            onSubmit(e) 
            {
                if(!this.checkNet()) return false;
                this.warningmsg = null; 
                this.successmsg = null;
                //this.showMessage();
                //alert('here');
                //return false;
                this.$validator.validateAll().then(result => {
                    if (!result) {
                        return;
                    }
                    e.preventDefault();
                    
                    var form_error = null;
                    
                    
                    if(!this.pool)
                    form_error = 'Select a Pool to continue!';
                    
                    if(!this.shift_group)
                    form_error = 'Select a Shift(Group) to continue!';
                    
                    
                    
                    if(form_error){
                        this.$bvToast.toast(form_error, {title: 'Error!!!',variant: 'danger',solid: true});
                        return false;
                    }
                    
                    
                    let currentObj = this;
                    let formData = new FormData();
                                        
                    
                    
                    
                    formData.append('pool', this.pool);
                    formData.append('shift', this.shift_group);
                    formData.append('month', this.month_selected);
                    formData.append('year', this.year_selected);
                    
                    

                    axios.post(this.pageurl+'/roster/saverosterinfo', formData)
                                .then(function (response) 
                                {
                                    this.successmsg = 'Saved!';   
                                    this.$bvToast.toast('Saved!', {
                                            title: `Success`,
                                            variant: 'success',
                                            solid: true
                                        });                                 
                                    this.resetForm();
                                    //this.movenext = true;
                                    //this.showMessage();
                                    this.$bvModal.hide('bv-modal-roster');
                                    this.getRosters();
                                }.bind(this))
                                .catch(function (error) 
                                {
                                    currentObj.serverError(error);
                                    currentObj.errormsg = error.response.data.errors;
                                });
                });
            },
            
            filterdatelist(){ 
                this.year_lists = [];
                var date = new Date();
                var year = date.getFullYear();
                this.year_selected = year;
                //alert(date.getMonth());
                this.month_selected = this.month_lists[date.getMonth()];
                for (var i = year - 2; i <= year ; i++) {
                this.year_lists.push(i);
            }
          }
        },
        created: function(){
            
            this.getRosterShiftGroups();
            this.getRosterPools();
            this.filterdatelist();
            this.getRosters();
        },
        computed: 
        {
            filteredData() 
            {
                let filtered_list = this.bankaccounts;
                if (this.search) 
                {
                    filtered_list = filtered_list.filter((row) => {return Object.keys(row).some((key) => {return String(row[key]).toLowerCase().indexOf(this.search.toLowerCase()) > -1;})});
                }                
                return filtered_list;
            },
            paginatedData() 
            {     
                return this.paginate(this.filteredData, this.length, this.pagination.currentPage);
            }
        }
    }
</script>