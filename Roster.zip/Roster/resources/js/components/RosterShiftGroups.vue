<template>       
    <div class="clearfix company-form-container rounded mt-4 pb-5 mx-auto pl-3 pr-3">
        
        

        <div class="clearfix row py-2 mb-2 border-bottom">       
            <div class="col-sm-3 px-3 company-form-box-title">Shift Groups</div> 
            <div class="col-sm-4">     
                <div class="custom-search float-right w-100">           
                    <b-input-group class="mb-0">
                        <b-input-group-prepend is-text>
                            <b-icon icon="search"></b-icon>
                        </b-input-group-prepend>
                        <b-form-input type="search" placeholder="Search.." v-model="search" @input="resetPagination()"></b-form-input>
                    </b-input-group>
                </div>
            </div>
            <div class="col-sm-5 float-right text-right px-0">
                <b-button id="show-btn" class="" @click="addNew(false)">Add Shift Group</b-button>
            </div>
        </div> 

        
        
        <div class="row justify-content-center">
            <div class="col-sm-12  px-0">
                <b-modal id="bv-modal-roster-shift-group" size="lg" hide-footer title="Shift  Details">
                    <b-overlay :show="showoverlay" rounded="sm">
                    
                            <b-form @submit.stop.prevent="onSubmit">                         
                                <div class="clearfix">
                                    <div class="px-3">
                                        <input type="hidden" v-model="fdata.id" name="id">
                                     
                                        <b-form-group id="name-group" label="Shift Group Name" class="required-field" label-for="title">
                                            <b-form-input id="title" name="title" v-model="fdata.title" v-validate="{ required: true, min: 3 }" :state="validateState('title')" aria-describedby="title-feedback" data-vv-as="Shift Group Name"></b-form-input>
                                            <b-form-invalid-feedback id="name-feedback">{{ veeErrors.first('title') }}</b-form-invalid-feedback>
                                        </b-form-group>
                                        
                                        
                                        
                                      
                                      
                                      <table class="table">
                                        <thead>
                                            <tr class="table-head">    
                                                <th>Select</th>                
                                                <th>Shift</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <template v-if="shifts">
                                             <tr class="table-row hover-bg" v-for="shift  in shifts" :key="'shift_'+shift.id"> 
                                               <td>
                                                <b-form-group :id="'shift-group-'+shift.id">
                                                <b-form-checkbox :id="'field_'+shift.id"  v-model="selected_shifts" :name="'field_'+shift.id" v-validate="{ required: false }"  :value="shift.id">
                                                    <!--State: <strong>{{ child_component_data[ch_popup_data.id] }}</strong>-->
                                                </b-form-checkbox>
                                                </b-form-group>
                                                </td>
                                                 <td>{{shift.title}}</td>
                                              </tr>
                                            </template>
                                        </tbody>
                                        <tfoot>
                                        <tr class=""><td class="px-0" colspan="2">
                                        &nbsp;
                                        </td></tr>
                                        </tfoot>
                                    </table>
                                        
                                       
                                       <b-form-group id="status-group" label="Status" label-for="status">
                                        <b-form-select id="status" name="status" v-model="fdata.status" :options="shift_status"></b-form-select>
                                       </b-form-group>

                                        
                                        <b-button v-if="fdata.id > 0" type="submit" variant="success" style="width: 100%;"><b-icon variant="light" icon="pencil" scale="1" width="20px" height="20px" class="align-left mr-2"></b-icon>Update Shift Group</b-button>
                                        <b-button v-else type="submit" variant="success" style="width: 100%;"><b-icon variant="light" icon="plus-circle" scale="1" width="20px" height="20px" class="align-left mr-2"></b-icon>Add Shift Group</b-button>
                                    </div>
                                </div>  
                            </b-form>
                    </b-overlay>
                </b-modal>

            </div>
    
    
            <div class="col-sm-12  px-0">            
                <b-overlay :show="showoverlay_list" rounded="sm">
                    <table class="table list-tables"> 
                        <thead>
                            <tr class="table-head">
                                <td class="pl-5">#</td>
                                <td class="">Shift Group Name</td>
                                <td class="">Shifts Under This Group</td>
                                <td>Status</td>
                                <td v-if="permission >= 2" class="float-right">Action</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="hover-bg table-row border-bottom mx-2" v-for="(shiftgroup , n) in paginatedData" :key="shiftgroup.id">
                                <td class="col-md-1 align-middle list-columns pl-5">{{shiftgroup.index}}</td>
                                <td class="col-md-3">
                                    {{shiftgroup.title}}
                                </td>
                                
                                <td class="col-md-8">
                                    {{shiftgroup.shift_names}}
                                </td>
                                
                                <td class="col-md-1 align-middle list-columns">
                                    {{shift_status[shiftgroup.status]}}
                                </td>  
                                                               
                                <td class="clearfix col-md-6 align-middle" v-if="permission >= 2">                        
                                    <div class="float-right mr-2 position-relative">
                                        <b-button-toolbar>
                                            <a id="actionDropdown" class="dropdown-toggle clearfix action-dropdown-toggle" style="font-size: 16px;" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><b-icon icon="three-dots-vertical"></b-icon></a>
                                             <div class="dropdown-menu action-dropdown-menu" aria-labelledby="actionDropdown">
                                                <b-button-group class="mr-0">
                                                    <b-button class="mr-3 rounded edit-btn" title="Edit Shift Info" @click="editShiftGroupInfo(shiftgroup.id)">
                                                        <b-icon icon="pencil" class="mr-2" aria-hidden="true" ></b-icon>Edit
                                                    </b-button>
                                                    
                                                    <b-button variant="outline-secondary" @click="deleteShiftGroup(shiftgroup.id)">
                                                     <b-icon icon="trash"></b-icon> Delete
                                                    </b-button>
                                                </b-button-group>
                                            </div>
                                        </b-button-toolbar>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div v-if="paginatedData.length == 0" class="px-3 py-3 no-result-cell">No Result Found!</div>
                    <div v-else class="px-3">
                        <ul class="pagination b-pagination float-left mb-0 mt-1">
                            <li class="page-item disabled m-2">View</li>
                            <li class="page-item disabled"><b-form-select v-model="temp_length" :options="length_options" @change="setFirstPage()"></b-form-select></li>
                            <li class="page-item disabled m-2">per page. Total {{totalrows}} records found.</li>
                        </ul>
                        <b-pagination-nav  v-model="pagination.currentPage" :number-of-pages="pagination.pages" base-url="#" prev-text="Previous" next-text="Next" first-number last-number ></b-pagination-nav>
                        
                    </div>
                
                
                
                    <div v-if="this.flg == 1" class="mt-3">                            
                        <b-button type="button" @click="set_go_next(1)" variant="primary" class="float-right mt-3 mr-3">Go Next</b-button>
                        <b-button type="button" @click="set_go_back(1)" variant="primary" class="float-right mt-3 mr-3">Go Back</b-button>
                        <b-button type="button" @click="setfinish(1)" variant="success" class="float-right mt-3 mx-3">Finish</b-button>
                    </div>
                
                </b-overlay>
            </div>

        </div>
        
    </div>
</template>


<script>
    export default{
        
        mounted() {
            this.permission = this.$acl['department/details'];
        },
        props: ['pageurl' , 'ce_flg' , 'check_ce' , 'flg'],
        data(){            
            
            return {                
                
                shifts:[], 
                selected_shifts:[],
                shiftgroups:[],             
                successmsg:null,
                errormsg:[],
                warningmsg:null,
                fdata: {name:null,status:null, id:null},
                saved_name : '',

                draftdata : {},
                pgurl:this.pageurl,
                file: null,   
                showoverlay:false,
                showoverlay_list:false,
                go_back : false,
                go_next : false,
                finish : false,
                
                search:'',
                length: 20,
                temp_length:20,
                totalrows:0,
                length_options: 
                [
                    { value: 20, text: "20" },
                    { value: 50, text: "50" },
                    { value: 100, text: "100" }
                ],
                shift_status: {0: "Pending", 1:"Active", 2: "Archived"},

                totalrows:0,
                pagination: {currentPage: 1, pages:1},

                successmsg:false,
                warningmsg:false,
                dangermsg:false,

                addtype : false,
              
                
                permission : 0,
                hasDraft : false,
                document : null,
            }
        },
        methods:{
            
            showMessage: function()
            {
                let tmp_flg = 0;
                if(this.shiftgroups.length > 0)tmp_flg = 1;               
                let childdata = {flg:tmp_flg , successmsg:this.successmsg , warningmsg:this.warningmsg , dangermsg:this.dangermsg,  move_next:this.go_next , move_back:this.go_back , finish:this.finish};                    
                this.$emit('childToParent', childdata);
            },
            set_go_back(x){
                this.go_next = false;
                this.go_back = true;
                this.finish = false;

                if(x == 1)
                    this.showMessage();
            },
            set_go_next(x){
                this.go_next = true;
                this.go_back = false;
                this.finish = false;

                if(x == 1)
                    this.showMessage();
            },
            disable_set_go_next(){
                this.go_next = false;
            },
            setfinish(x){
                this.finish = true;

                this.go_next = false;
                this.go_back = false;

                if(x == 1)
                    this.showMessage();
            },


            addNew(x)
            {
                this.addtype = x;
                this.resetForm();
                this.$bvModal.show('bv-modal-roster-shift-group');
                //this.newagent = true;
            },
            
            getRosterShifts: function()
            {
                if(!this.checkNet()) return false;
                let currentObj = this;
                axios.get(this.pageurl+'/roster/shifts' , {
                    params: {
                        status: 1
                    }
                }).then(function(response){
                    this.shifts = response.data;
                    //this.totalrows = this.shifts.length;
                    //this.showMessage();

                }.bind(this)).catch(function (error){currentObj.serverError(error);});
            },
            
            getRosterShiftGroups: function()
            {
                if(!this.checkNet()) return false;
                let currentObj = this;
                axios.get(this.pageurl+'/roster/shiftgroups' , {
                    params: {
                        //status: 1
                    }
                }).then(function(response){
                    this.shiftgroups = response.data;
                    this.totalrows = this.shiftgroups.length;
                    //this.showMessage();

                }.bind(this)).catch(function (error){currentObj.serverError(error);});
            },
            
            editShiftGroupInfo:function(x)
            {  
                this.addtype = false;
                if(!this.checkNet()) return false;
                let currentObj = this; 
                this.showoverlay = true;
                axios.get(this.pageurl+'/roster/shiftgroupdetails' , {
                    params: {
                        id: x
                    }
                }).then(function(response){
                    this.fdata = response.data;
                    this.selected_shifts = this.fdata.group_options;
                    this.$validator.reset();                    
                    this.showoverlay = false;
                    this.$bvModal.show('bv-modal-roster-shift-group');
                }.bind(this)).catch(function (error){currentObj.showoverlay = false; currentObj.serverError(error);}); ;                
            },
            
          deleteShiftGroup:function(x)
            {
                if(!this.checkNet()) return false;
                this.$bvModal.msgBoxConfirm('Please confirm that you want to delete this shift group.', {
                    title: 'Please Confirm', size: 'sm', buttonSize: 'sm', okVariant: 'primary', okTitle: 'Yes', cancelTitle: 'Cancel', footerClass: 'p-2', hideHeaderClose: false,centered: true
                })
                .then(value => {                    
                    if(value)
                    {
                        //alert(x);
                        let currentObj = this;
                        //this.showoverlay_list = true;
                        let formData = new FormData();
                        formData.append('id', x);
                        
                        axios.post(this.pageurl+'/roster/shiftgroup/delete', formData).then(function(response){

                            if(response.data.status == true)
                            {
                                //this.successmsg = response.data.meg; 
                                this.$bvToast.toast(response.data.msg, {
                                            title: `Success`,
                                            variant: 'success',
                                            solid: true
                                        });

                                this.getRosterShiftGroups();                         
                            }
                            else
                            {
                              
                                this.$bvToast.toast(response.data.msg, {
                                            title: `Warning`,
                                            variant: 'warning',
                                            solid: true
                                        });
                            }
                            
                            
                        }.bind(this))
                        .catch(function (error) 
                        {
                            currentObj.serverError(error);
                        });
                    }
                })
                .catch(err => {
                    // An error occurred
                })    
            },
            validateState(ref)
            {
                if (
                    this.veeFields[ref] &&
                    (this.veeFields[ref].dirty || this.veeFields[ref].validated)
                ) {
                    return !this.veeErrors.has(ref);
                }
                return null;
            },
            resetForm()
            {
                this.fdata = {name:null, status:null, id:null};                
                
                this.$nextTick(() => {
                    this.$validator.reset();
                });
            },
            onSubmit(e) 
            {
                if(!this.checkNet()) return false;
                this.warningmsg = null; 
                this.successmsg = null;
                //this.showMessage();
                this.$validator.validateAll().then(result => {
                    if (!result) {
                        return;
                    }

                    e.preventDefault();
                    let currentObj = this;
                    

                    let formData = new FormData();
                                        
                    for (let [key, value] of Object.entries(this.fdata)) 
                    {                    
                        var nm = `${key}`;
                        var fval = `${value}`;
                        formData.append(nm, fval);                    
                        //console.log(`${key}: ${value}`);
                    } 
                    
                    formData.append('shifts', this.selected_shifts);  

                    axios.post(this.pageurl+'/roster/saveshiftgroup', formData)
                                .then(function (response) 
                                {
                                    
                                    
                                    currentObj.getRosterShiftGroups();

                                    currentObj.successmsg = 'Saved!';   
                                    currentObj.$bvToast.toast('Saved!', {
                                            title: `Success`,
                                            variant: 'success',
                                            solid: true
                                        });                                 
                                    currentObj.resetForm();
                                    //this.movenext = true;
                                    //this.showMessage();
                                    currentObj.$bvModal.hide('bv-modal-roster-shift-group');
                                    
                                }.bind(this))
                                .catch(function (error) 
                                {
                                    currentObj.serverError(error);
                                    //currentObj.errormsg = error.response.data.errors;
                                   
                                });
                });
            },

        },
        created: function(){
            this.getRosterShifts();
            this.getRosterShiftGroups();
            //this.getDraftDepartmentData();
            //Fire.$on('reloadUsers', () => {this.getCategoryInvestmentshifts()});
        },
        computed: 
        {
            filteredData() 
            {
                let filtered_list = this.shiftgroups;
                if (this.search) 
                {
                    filtered_list = filtered_list.filter((row) => {return Object.keys(row).some((key) => {return String(row[key]).toLowerCase().indexOf(this.search.toLowerCase()) > -1;})});
                }                
                return filtered_list;
            },
            paginatedData() 
            {     

                //console.log(this.length);
                //console.log(this.filteredData);

                return this.paginate(this.filteredData, this.length, this.pagination.currentPage);
            }
        }
    }
</script>