  <template>
  <b-overlay :show="showoverlay" rounded="sm">
  <div class="users-style">
  <h4 class="atlhr-dashboard-title mt-10 pb-4 mb-0">Rosters for {{roster_name}}<span><a v-bind:href="pageurl+'/company/dashboard'">Dashboard</a> / Roster / Details</span></h4>


    <div class="row no-gutters py-2 mb-3 border-bottom">
            <div class="col-sm-6 cursor-pointer company-form-box-title pr-0">
               Roster Shift
               <b-form-select v-model="group_selected" :options="shiftgroups" class="w-75" @change="getRosterDetails()"></b-form-select>
               </div>
               <div class="col-sm-6 cursor-pointer text-right company-form-box-title pr-0">
               Roster Date 
               <b-form-select v-model="roster_day_selected" :options="roster_days_lists" class="w-75" @change="getRosterDetails()"></b-form-select>
            </div>
     </div>
	<table class="table table-hover">
	  <tbody>
        <tr class="table-head">
          
          <td style="text-align: left;">Employee Name</td>
		  <td style="text-align: left;">Employee Code</td>
          <td style="text-align: left;">Action</td>
          <!--<td style="text-align: center;">Delete</td>-->
		</tr>
       <template v-if="paginatedData.length">
		<tr class="table-row hover-bg" v-for="(roster,index) in paginatedData" :key="roster.id">
		  <td>{{roster.name}}</td>
          <td>{{roster.employee_code}}</td>
          <td><a href="javascript: void(0)" @click="updateemployeeshift(roster.employee_id,roster.id)">Update Shift</a></td>

        </tr>
        
        <tr v-if="paginatedData.length > 0"><td :colspan=6>
                <div class="row p-2 float-right" >
                    <b-pagination-nav  v-model="pagination.currentPage" :number-of-pages="pagination.pages" prev-text="Previous" next-text="Next" base-url="#" first-number last-number ></b-pagination-nav>
        </div></td></tr>
        
        
        </template>
        <template v-else>
          <tr>
            <td colspan="7">{{data_not_available}}</td>
          </tr>
        </template>
        
	  </tbody>
  </table>
  </div>
  
       <b-modal id="bv-modal-update-shift" size="lg" hide-footer title="Shift  Details">
                    <b-overlay :show="showoverlay" rounded="sm">
                    
                            <b-form @submit.stop.prevent="switchShift">                         
                                <div class="clearfix">
                                    <div class="px-3">
                                        <input type="hidden" v-model="shift_employee_id" name="id"/>
                                     
                                        <b-form-group id="employee_shift-group" label="Shift(Group)" label-for="employee_shift" class="required-field">
                                            <b-form-select name="employee_shift" class='form-control' v-model="employee_shift" :options="shiftgroups" v-validate="{ required: true }" :state="validateState('employee_shift')" aria-describedby="employee_shift-feedback" data-vv-as="Shift">
                                            </b-form-select>
                                            <b-form-invalid-feedback id="employee_shift-feedback">{{ veeErrors.first('employee_shift') }}</b-form-invalid-feedback>
                                        </b-form-group>
                                     
                                        <b-button type="submit" variant="success" style="width: 100%;"><b-icon variant="light" icon="pencil" scale="1" width="20px" height="20px" class="align-left mr-2"></b-icon>Update Shift</b-button>
                                        
                                    </div>
                                </div>  
                            </b-form>
                    </b-overlay>
                </b-modal>
  
  
   </b-overlay>
  </template> 
  <script>
	  export default{
		  props: ['pageurl','roster','rostertitle','pool'],
		  mounted() {          
		  },
		  data(){
			  return {
				  rosters : [],             
				  length : 10,
                  pagination : {currentPage: 1,total: '',nextPage: '',prevPage: '',from: '',to: '', pages:1},
				  search : '',
				  search_by_id:{payrun_id:'', payrun_id_form:''},
				  per_page:10,  
                  sortOrders: {},            
				  pgurl:this.pageurl,
                  
                  showoverlay : false,
                  data_not_available: 'Loading please wait....',
                  year_lists: [], 
                  year_selected: null,
                  month_lists: ["January","February","March","April","May","June","July","August","September","October","November","December"],
                  month_selected: null, 
                  location_info: '',
                  roster_id: this.roster,
                  pool_id: this.pool,
                  roster_name: this.rostertitle,
                  group_selected: 0,
                  shiftgroups: [],
                  roster_day_selected: 0,
                  roster_days_lists: [],
                  employee_shift: 0,
                  shift_employee_id: 0,
                  shift_employee_roster_id: 0,
                  
			  }
		  },
		  methods:{
			  setPagination: function(pageflg)
			  {                
				  if(pageflg)
					  this.pagination.currentPage = this.pagination.nextPage;
				  else    
					  this.pagination.currentPage = this.pagination.prevPage;
				  
				  this.getRosterDetails();
			  },
              
              filterdatelist(){ 
                this.year_lists = [];
                var date = new Date();
                var year = date.getFullYear();
                this.year_selected = year;
                //alert(date.getMonth());
                this.month_selected = this.month_lists[date.getMonth()];
                for (var i = year - 2; i <= year ; i++) {
                this.year_lists.push(i);
              }

             },  
             
             updateemployeeshift: function(emp_id,roster_id)
			  {
			    
                     if(emp_id){
                         this.location_info = 'Loading....';
                         this.employee_shift =  this.group_selected;
                         this.shift_employee_id = emp_id;
                         this.shift_employee_roster_id = roster_id;
                         this.$bvModal.show('bv-modal-update-shift');
                     }
			  },
             
			  getRosterDetails: function()
			  {
			    
                     this.showoverlay = true;
                     this.data_not_available = 'Loading please wait....';
                     if(!this.group_selected)
                     return 1;
                     
                     axios.get(this.pageurl+'/roster/getshiftrosterdetails' , {
							  params: {
								  rs_id: this.roster_id,
								  shift_id: this.group_selected,
                                  pool_id: this.pool_id,
                                  roster_id: this.roster_day_selected
							  }
					  }).then(function(response){
					  this.roster_days_lists = response.data.date_lists;
                      this.roster_day_selected = response.data.roster_selected;
                      this.rosters = response.data.roster_data;
					  /*this.pagination.from = response.data.from;
					  this.pagination.to = response.data.to;*/
					  this.pagination.total = response.data.roster_data.total;
                      
                      this.showoverlay = false;
                      if(this.rosters && this.rosters.length>0)
                      this.data_not_available = '';
                      else
                      this.data_not_available = 'Roster data not available...';
					  
					  if(this.pagination.to==this.pagination.total)
					  {
						  
						  this.pagination.nextbuttonstatus = 'disabled';
						  
					  }
					  else
					  {
						   this.pagination.nextbuttonstatus = '';
					  }
					  
					  if(this.pagination.from==1)
					  {
					  this.pagination.prebuttonstatus = 'disabled';
					  }
					  else
					  {
						 this.pagination.prebuttonstatus = ''; 
					  }
  
  
  
					  if(this.pagination.currentPage < response.data.last_page)
						  this.pagination.nextPage = this.pagination.currentPage + 1;
  
					  if(this.pagination.currentPage == 1)
						  this.pagination.prevPage = 1;
					  else 
						  this.pagination.prevPage = this.pagination.currentPage - 1;
				  }.bind(this));
			  },
              
              rostergroupinfo: function()
			  {
			    
                     this.showoverlay = true;
                     
                     if(this.roster_id){
                         axios.get(this.pageurl+'/roster/custominfo' , {
    							  params: {
    								  roster_id: this.roster_id
    							  }
    					  }).then(function(response){
    					  this.shiftgroups = response.data;
                          if(!this.group_selected)
                          this.group_selected = this.shiftgroups[0].value;
                          
                          
                          this.showoverlay = false;
                          
                          this.getRosterDetails();

    				  }.bind(this));
                  }
			  },

           validateState(ref)
            {
                if (
                    this.veeFields[ref] &&
                    (this.veeFields[ref].dirty || this.veeFields[ref].validated)
                ) {
                    return !this.veeErrors.has(ref);
                }
                return null;
            },
			  
			  
	          onImageChange(e){
				  //console.log(e.target.files[0]);
				  this.image = e.target.files[0];
			  },

              ///////////////////////////////////////
              
           switchShift(e) 
            {
                if(!this.checkNet()) return false;
                
                this.$validator.validateAll().then(result => {
                    if (!result) {
                        return;
                    }
                    e.preventDefault();
                    
                    var form_error = null;
                    
                    
                    
                    
                    if(!this.shift_employee_id)
                    form_error = 'Form error please refresh and try again!';
                    
                    if(!this.employee_shift)
                    form_error = 'Select a Shift(Group) to continue!';
                    
                    if(!this.shift_employee_roster_id)
                    form_error = 'Form error please refresh and try again!';
                    
                    
                    if(form_error){
                        this.$bvToast.toast(form_error, {title: 'Error!!!',variant: 'danger',solid: true});
                        return false;
                    }
                    
                    
                    let currentObj = this;
                    let formData = new FormData();
                                        
                    
                    
                    
                  
                    formData.append('shift', this.employee_shift);
                    formData.append('employee_id', this.shift_employee_id);
                     formData.append('roster_id', this.shift_employee_roster_id);
                    
                    

                    axios.post(this.pageurl+'/roster/switchshift', formData)
                                .then(function (response) 
                                {
                                    this.successmsg = 'Saved!';   
                                    this.$bvToast.toast('Saved!', {
                                            title: `Success`,
                                            variant: 'success',
                                            solid: true
                                        });                                 
                                    //this.movenext = true;
                                    //this.showMessage();
                                    this.$bvModal.hide('bv-modal-update-shift');
                                    this.getRosterDetails();
                                }.bind(this))
                                .catch(function (error) 
                                {
                                    currentObj.serverError(error);
                                    currentObj.errormsg = error.response.data.errors;
                                });
                });
            },
			 
  
  
		  },
		      created: function(){
              this.rostergroupinfo();
              //this.filterdatelist();
			  this.getRosterDetails();
		      
		  },
      computed: 
        {
            filteredData() 
            {
                let filtered_list = this.rosters;
                if (this.search) 
                {
                    filtered_list = filtered_list.filter((row) => {return Object.keys(row).some((key) => {return String(row[key]).toLowerCase().indexOf(this.search.toLowerCase()) > -1;})});
                
                    if(filtered_list.length == 0)
                        this.blankmsg = "Nothing found.";                
                }

                let sortKey = this.sortKey;
                let order = this.sortOrders[sortKey] || 1;
                if (sortKey) 
                {
                    filtered_list = filtered_list.slice().sort((a, b) => {let index = this.getIndex(this.columns, 'name', sortKey);
                            a = String(a[sortKey]).toLowerCase();
                            b = String(b[sortKey]).toLowerCase();
                            if (this.columns[index].type && this.columns[index].type === 'date') 
                            {
                                return (a === b ? 0 : new Date(a).getTime() > new Date(b).getTime() ? 1 : -1) * order;
                            } 
                            else if (this.columns[index].type && this.columns[index].type === 'number') 
                            {
                                return (+a === +b ? 0 : +a > +b ? 1 : -1) * order;
                            } 
                            else 
                            {
                                return (a === b ? 0 : a > b ? 1 : -1) * order;
                            }
                        }
                    );
                }
                
                return filtered_list;
            },
            paginatedData() 
            {     
                return this.paginate(this.filteredData, this.length, this.pagination.currentPage);
            },
            
            
        }
	  }
  </script>
  <style>
  button.disabled{
	  cursor: default;
  }
   .tb-border{
    border: 1px solid #808080;
    border-radius: 0.25rem !important;
    border-collapse: separate;
}

.tb-border td{
    padding: 2px !important;
}
.year-wrapper{margin-right: 10px !important;max-width: 18%;}
  </style>