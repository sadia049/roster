<template>
    <div class="employee-tab-inner">        
        <!--<ul class="list-group mb-3 " v-if='errormsg'>           
            <li class="list-group-item list-group-item-danger" v-for='data in errormsg'>{{data[0]}}</li>
        </ul>-->     
        <b-overlay :show="showoverlay" rounded="sm">
            <div class="pf-reporting-tab payroll-reporting-tab" id="nav-tabContent-intro3">
                 <b-tabs content-class="mt-3 reports-tab-wrapper" nav-wrapper-class="mb-2 mt-2 reports-tab-nav-wrapper">
                                        
                    <b-form>
                        <!-- <input type="hidden" v-model="fdata.employee_id" name="employee_id"> -->

                        <b-tab lazy active>

                            <template #title>
                                <div class="report-title w-100 border-bottom font-weight-bold pb-2 mb-2">
                                    <img v-bind:src="pageurl+'/public/images/Monthly-report-black.png'" class="light-mode-icon" width="50px"/><img v-bind:src="pageurl+'/public/images/Monthly-report.png'" class="dark-mode-icon" width="50px"/>Roster Shifts
                                </div>
                                <div class="report-intro">
                                    Roster Shifts
                                </div>
                                <b-button class="mt-3">View</b-button>
                            </template>
                            <div class="">
                            <roster-shifts :pageurl="pageurl"></roster-shifts>
                            </div>

                        </b-tab>
                        <b-tab lazy>

                            <template #title>
                                <div class="report-title w-100 border-bottom font-weight-bold pb-2 mb-2">
                                    <img v-bind:src="pageurl+'/public/images/Monthly-report-black.png'" class="light-mode-icon" width="50px"/><img v-bind:src="pageurl+'/public/images/Monthly-report.png'" class="dark-mode-icon" width="50px"/>Roster Shift Groups
                                </div>
                                <div class="report-intro">
                                    Roster Shift Groups 
                                </div>
                                <b-button class="mt-3">View</b-button>
                            </template>
                            <div class="">
                            <roster-shift-groups :pageurl="pageurl"></roster-shift-groups>
                            </div>
                        </b-tab> 
                    </b-form>
                    <!-- Form ends here -->
                </b-tabs>
            </div>
            
            <div class="row justify-content-center">
            <div class="col-sm-12  px-0">
                <b-modal id="bv-modal-investment-susd" size="lg" hide-footer title="Software Usage Start Date (SUSD) ">
                   
                    
                            <b-form @submit.stop.prevent="susdUpdate">                         
                                <div class="clearfix">
                                    <div class="px-3">
                                        
                                        <b-form-group id="susd-group" label="Software Usage Start Date" label-for="susd" class="my-2">
                                            <b-form-datepicker id="susd" name="contract_start" v-model="susd" :aria-required="true" v-validate="{ required: true}" :state="validateState('susd')" aria-describedby="susd-feedback" data-vv-as="Software Usage Start Date(SUSD)" reset-button></b-form-datepicker>
                                            <b-form-invalid-feedback id="susd">{{ veeErrors.first('susd') }}</b-form-invalid-feedback>
                                        </b-form-group>
                                        
                                        <b-button  type="submit" variant="success" style="width: 100%;"><b-icon variant="light" icon="pencil" scale="1" width="20px" height="20px" class="align-left mr-2"></b-icon>UPDATE</b-button>
                                        
                                    </div>
                                </div>  
                            </b-form>
                    
                </b-modal>

            </div>
          </div>  
        </b-overlay>
        
    </div>
    
</template>
 
<script>
    import moment from 'moment';

    export default{
        
        mounted() {
            
            this.showoverlay = false;
        },
        props: ['flg','pageurl'],

        data(){            
            
            return {
                
                


                componentKey: 0,
                     
                cu:window.location.href,
                successmsg : false,
                warningmsg : false,
                dangermsg : false,
                showoverlay : true,
                //susdoverlay : false,
                readonly : false,
                user_level : 0,
                

                errormsg:[],
                
                fdata: {
                        },

                susd: '',
            }
        },
        methods:{
            
            validateState(ref)
            {
                if (
                    this.veeFields[ref] &&
                    (this.veeFields[ref].dirty || this.veeFields[ref].validated)
                ) {
                    return !this.veeErrors.has(ref);
                }
                return null;
            },

            
            formatMoney: function(amount){
                var money = Number(amount);
                money = money.toLocaleString();
                if(money=='NaN')
                money = amount;
                else{
                if(money.indexOf(".")<0)
                money = money+".00";
                }
                return money;
            },  
            
            showSusd()
            {
                //this.addtype = x;
                //this.resetForm();
                let currentObj = this; 
                this.showoverlay = true;
                axios.get(this.pageurl+'/fundinvestment/susd' , {
                    params: {
                    }
                }).then(function(response){
                    this.susd = response.data;
                    this.$validator.reset();                    
                    this.showoverlay = false;
                    this.$bvModal.show('bv-modal-investment-susd');
                }.bind(this)).catch(function (error){currentObj.showoverlay = false; currentObj.serverError(error);});
                
                
                //this.newagent = true;
            },
            susdUpdate(e) 
            {
                if(!this.checkNet()) return false;
                //this.showMessage();
                e.preventDefault();
                let currentObj = this;
                let formData = new FormData();
                                        
                formData.append('susd', this.susd);
                axios.post(this.pageurl+'/fundinvestment/savesusd', formData)
                                .then(function (response) 
                                {
                                    
                                    currentObj.successmsg = 'Saved!';   
                                    currentObj.$bvToast.toast('Saved!', {
                                            title: `Success`,
                                            variant: 'success',
                                            solid: true
                                        });                                 
                                    currentObj.$bvModal.hide('bv-modal-investment-susd');
                                    
                                }.bind(this))
                                .catch(function (error) 
                                {
                                    currentObj.serverError(error);
                                    //currentObj.errormsg = error.response.data.errors;
                                   
                                });
                
            }
        },
        computed: 
        {
        },
        created: function(){
            if(!this.checkNet()) return false;
            this.$validator.reset();
        }
    }
</script> 
