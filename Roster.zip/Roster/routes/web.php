<?php
/*-----------------Start Roster--------------*/
Route::get('roster/home', 'RosterController@dashboard');
Route::get('roster/shifts', 'RosterController@shifts');
Route::post('roster/saveshiftinfo', 'RosterController@saveshiftdata');
Route::get('roster/shiftdetails', 'RosterController@shiftdetails');
Route::post('roster/shift/delete', 'RosterController@shiftdelete');

Route::get('roster/shiftgroups', 'RosterController@shiftgroups');
Route::post('roster/saveshiftgroup', 'RosterController@saveshiftgroupdata');
Route::get('roster/shiftgroupdetails', 'RosterController@shiftgroupdetails');
Route::post('roster/shiftgroup/delete', 'RosterController@shiftgroupdelete');
Route::get('roster/pool', 'RosterController@rosterpools');
Route::post('roster/saverosterinfo', 'RosterController@saverosterdata');
Route::get('roster/rosters', 'RosterController@allrosters');
Route::get('roster/groupdetails', 'RosterController@rostergroupdetails');
Route::get('roster/custominfo', 'RosterController@custom_roster_info');

Route::get('roster/getshiftrosterdetails', 'RosterController@shiftrosterdetails');

Route::post('roster/switchshift', 'RosterController@updateemployeeshift');
/*-----------------End Roster--------------*/

?>